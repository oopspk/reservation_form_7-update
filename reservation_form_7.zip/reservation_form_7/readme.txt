==== reservation form ====
Contributors: oops.pk
Tags: reservation form ,reservation form
Requires at least: 4.9
Tested up to: 6.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



=== Description ===

WP reservation form is the best free WordPress Plugin for you to build a reservation form managed and maintained by Oops.pk This plugin can be used for any company or office reservations services with an excellent online reservation system.
If you still get confused about how to build your dream reservation form just use Wp Reservation form. Everything is ready for you to use, just import your data with 1 click and wait for the magic to happen.

Features:
You can create reservation form..
Can be added one or more select boxes.
Data can easily be put through short codes

=== Installation ===

1. Search for and install the 'wp reservation form'.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate form the Dashboard to the wp reservation form to make sure it is installed.

=== Instructions ===
Administrator will click wp Reservation than form will appear over it he can manage and add desired select boxes labels and and put data.




