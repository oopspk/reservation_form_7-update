<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
// create custom plugin settings menu
add_action('admin_menu', 'oopspk_reservation_create_menu');

function oopspk_reservation_create_menu() {

	//create new top-level menu
	add_menu_page('Reservation Form 7', 'Reservation Form', 'administrator', __FILE__, 'oopspkreservation_form_settings_page' , '' );

	//call register settings function
	add_action( 'admin_init', 'oopspkreservation_form_plugin_settings' );
}


function oopspkreservation_form_plugin_settings() {
	//register our settings
	register_setting( 'oops-reservation-from-settings-group', 'new_option_name' );
	register_setting( 'oops-reservation-from-settings-group', 'some_other_option' );
	register_setting( 'oops-reservation-from-settings-group', 'option_etc' );

  if(isset($_POST['submit_customization'])){
  //echo $_POST['tag_field1'];
$tag_field1 = esc_attr(ucwords($_POST['tag_field1']));
$tag_field2 = esc_attr(ucwords($_POST['tag_field2']));
$tag_field3 = esc_attr(ucwords($_POST['tag_field3']));
$tag_field4 = esc_attr(ucwords($_POST['tag_field4']));

$option_name = 'tag_select_field1';
update_option( $option_name, $tag_field1 );

$option_name = 'tag_select_field2';
update_option( $option_name, $tag_field2 );

$option_name = 'tag_select_field3';
update_option( $option_name, $tag_field3 );

$option_name = 'tag_select_field4';
update_option( $option_name, $tag_field4 );

 $new_value_tags = array("field1"=>$tag_field1, "field2"=>$tag_field2, "field3"=>$tag_field3, "field4"=>$tag_field4);
$option_name = 'oops_wp_reservation_fields_tag';
update_option( $option_name, $new_value_tags );

//* fields types*//

$fieldtype1 = esc_attr(ucwords($_POST['fieldtype1']));
$fieldtype2 = esc_attr(ucwords($_POST['fieldtype2']));
$fieldtype3 = esc_attr(ucwords($_POST['fieldtype3']));
$fieldtype4 = esc_attr(ucwords($_POST['fieldtype4']));

$option_name = 'fieldtype1';
update_option( $option_name, $fieldtype1 );

$option_name = 'fieldtype2';
update_option( $option_name, $fieldtype2 );

$option_name = 'fieldtype3';
update_option( $option_name, $fieldtype3 );

$option_name = 'fieldtype4';
update_option( $option_name, $fieldtype4 );

$new_value_type = array("field1"=>$fieldtype1, "field2"=>$fieldtype2, "field3"=>$fieldtype3, "field4"=>$fieldtype4);
$option_name = 'oops_wp_reservation_fields_type';
update_option( $option_name, $new_value_type );

//*Labels Names*//
$inputfield1 = esc_attr(ucwords($_POST['inputfield1']));
$inputfield2 = esc_attr(ucwords($_POST['inputfield2']));
$inputfield3 = esc_attr(ucwords($_POST['inputfield3']));
$inputfield4 = esc_attr(ucwords($_POST['inputfield4']));

$option_name = 'inputfield1';
update_option( $option_name, $inputfield1 );

$option_name = 'inputfield2';
update_option( $option_name, $inputfield2 );

$option_name = 'inputfield3';
update_option( $option_name, $inputfield3 );

$option_name = 'inputfield4';
update_option( $option_name, $inputfield4 );

$new_value_type = array("field1"=>$inputfield1, "field2"=>$inputfield2, "field3"=>$inputfield3, "field4"=>$inputfield4);
$option_name = 'oops_wp_reservation_label_name';
update_option( $option_name, $new_value_type );
}

}
function oopspkreservation_form_settings_page() {
?>
<div class="wrap">
<img src="<?php echo plugin_dir_url( __FILE__ ).'/assets/images/logo_plugin.png';?>" class="plugin_logo_main">

<hr>

<div class="tabset">
  <!-- Tab 1 -->
  <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked>
  <label for="tab1">Customization</label>
  <!-- Tab 2 -->
  <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
  <label for="tab2">Add Options </label>
  <!-- Tab 3 -->
  <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
  <label for="tab3">Form Entry</label>
  
  <div class="tab-panels">
    <section id="marzen" class="tab-panel" >
      <h2>Customization</h2>
  <div style="float: right; margin-bottom: 10px;">
      Shortcode: <input value="[oops_wp_reservation_form_shortcode]" style="width: 250px; height: 40px;">
  </div>  
<?php require(wp_reservation_dir."/inc/oopspk_customization.php");?>
  </section>
    <section id="rauchbier" class="tab-panel">
      <h2>Add Options </h2>
<?php require(wp_reservation_dir."/inc/oopspk_add_options.php");?>
    </section>
    <section id="dunkles" class="tab-panel">
      <h2>Form Entry</h2>
  
    </section>
  </div>
</div>
</div>
<?php } ?>
