<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
add_shortcode('oops_wp_reservation_form_shortcode', 'oops_wp_reservation_form_func' );
 
function oops_wp_reservation_form_func() {
///*tag_select_field*//
$tag_select_field1 = get_option('tag_select_field1');
$tag_select_field2 = get_option('tag_select_field2');
$tag_select_field3 = get_option('tag_select_field3');
$tag_select_field4 = get_option('tag_select_field4');
///*fieldtype*//
$fieldtype1 = get_option('fieldtype1');
$fieldtype2 = get_option('fieldtype2');
$fieldtype3 = get_option('fieldtype3');
$fieldtype4 = get_option('fieldtype4');
///*inputfield*//
$inputfield1 = get_option('inputfield1');
$inputfield2 = get_option('inputfield2');
$inputfield3 = get_option('inputfield3');
$inputfield4 = get_option('inputfield4');
///*addoptions_value_field1*//
$addoptions_value_field1 = get_option('addoptions_value_field1');
$addoptions_value_field2 = get_option('addoptions_value_field2');
$addoptions_value_field3 = get_option('addoptions_value_field3');
$addoptions_value_field4 = get_option('addoptions_value_field4');

ob_start();

?>
 <div class="container">
  <form action="" method="post">

<?php
if($tag_select_field1 == 'Input'){
?>
    <label for="<?php echo esc_attr(ucwords($inputfield1));?>"><?php echo esc_attr(ucwords($inputfield1));?></label>
    <input type="<?php echo esc_attr(ucwords($fieldtype1));?>" id="<?php echo esc_attr(ucwords($inputfield1));?>" name="field1" placeholder="<?php echo esc_attr(ucwords($inputfield1));?>" class="input_box">
<?php
}
if($tag_select_field1 == 'Select'){
?>
 <label for="<?php echo esc_attr(ucwords($inputfield1));?>"><?php echo esc_attr(ucwords($inputfield1));?></label>
    <select id="<?php echo esc_attr(ucwords($inputfield1));?>" name="field1">
 <?php
$ex_array = $addoptions_value_field1['field1_add_options'];
array_unshift($ex_array,"");
unset($ex_array[0]); 
      	foreach ($ex_array as $key => $value_field1) {

      		echo '<option value='.esc_attr($key).'>'.esc_attr(ucwords($value_field1)).'</option>';
      	}
      ?>
    </select>
<?php	
}
if($tag_select_field1 == 'Textarea'){
?>
   <label for="<?php echo esc_attr(ucwords($inputfield1));?>"><?php echo esc_attr(ucwords($inputfield1));?></label>
    <textarea id="<?php echo esc_attr(ucwords($inputfield1));?>" name="field1" placeholder="<?php echo esc_attr(ucwords($inputfield1));?>" style="height:200px"></textarea>
<?php	
}
?>

<!---------------------------------------------------------------------------->
<?php
if($tag_select_field2 == 'Input'){
?>
    <label for="<?php echo esc_attr(ucwords($inputfield2));?>"><?php echo esc_attr(ucwords($inputfield2));?></label>
    <input type="<?php echo esc_attr(ucwords($fieldtype2));?>" id="<?php echo esc_attr(ucwords($inputfield2));?>" name="field2" placeholder="<?php echo esc_attr(ucwords($inputfield2));?>" class="input_box">
<?php
}
if($tag_select_field2 == 'Select'){
?>
 <label for="<?php echo esc_attr(ucwords($inputfield2));?>"><?php echo esc_attr(ucwords($inputfield2));?></label>
    <select id="<?php echo esc_attr(ucwords($inputfield2));?>" name="field2">
 <?php
 $ex_array = $addoptions_value_field2['field2_add_options'];
array_unshift($ex_array,"");
unset($ex_array[0]); 
      	foreach ($ex_array as $key => $value_field2) {

      		echo '<option value='.esc_attr($key).'>'.esc_attr(ucwords($value_field2)).'</option>';

      	}
      ?>
    </select>
<?php	
}
if($tag_select_field2 == 'Textarea'){
?>
   <label for="<?php echo esc_attr(ucwords($inputfield2));?>"><?php echo esc_attr(ucwords($inputfield2));?></label>
    <textarea id="<?php echo esc_attr(ucwords($inputfield2));?>" name="field2" placeholder="<?php echo esc_attr(ucwords($inputfield2));?>" style="height:200px"></textarea>
<?php	
}
?>

<!----------------------------------------------------------------------------->
<?php
if($tag_select_field3 == 'Input'){
?>
    <label for="<?php echo esc_attr(ucwords($inputfield3));?>"><?php echo esc_attr(ucwords($inputfield3));?></label>
    <input type="<?php echo esc_attr(ucwords($fieldtype3));?>" id="<?php echo esc_attr(ucwords($inputfield3));?>" name="field3" placeholder="<?php echo esc_attr(ucwords($inputfield3));?>" class="input_box">
<?php
}
if($tag_select_field3 == 'Select'){
?>
 <label for="<?php echo esc_attr(ucwords($inputfield3));?>"><?php echo esc_attr(ucwords($inputfield3));?></label>
    <select id="<?php echo esc_attr(ucwords($inputfield3));?>" name="field3">
      <?php
$ex_array = $addoptions_value_field3['field3_add_options'];
array_unshift($ex_array,"");
unset($ex_array[0]); 
foreach ($ex_array as $key => $value_field3) {

echo '<option value='.esc_attr($key).'>'.esc_attr(ucwords($value_field3)).'</option>';

   }

 ?>
    </select>
<?php	
}
if($tag_select_field3 == 'Textarea'){
?>
   <label for="<?php echo esc_attr(ucwords($inputfield3));?>"><?php echo esc_attr(ucwords($inputfield3));?></label>
    <textarea id="<?php echo esc_attr(ucwords($inputfield3));?>" name="field3" placeholder="<?php echo esc_attr(ucwords($inputfield3));?>" style="height:200px"></textarea>
<?php	
}
?>
<!----------------------------------------------------------------------------->
<?php
if($tag_select_field4 == 'Input'){
?>
    <label for="<?php echo esc_attr(ucwords($inputfield4));?>"><?php echo esc_attr(ucwords($inputfield4));?></label>
    <input type="<?php echo esc_attr(ucwords($fieldtype4));?>" id="<?php echo esc_attr(ucwords($inputfield4));?>" name="field4" placeholder="<?php echo esc_attr(ucwords($inputfield4));?>" class="input_box">
<?php
}
if($tag_select_field4 == 'Select'){
?>
 <label for="<?php echo esc_attr(ucwords($inputfield4));?>"><?php echo esc_attr(ucwords($inputfield4));?></label>
    <select id="<?php echo esc_attr(ucwords($inputfield4));?>" name="field4">
       <?php
         $ex_array = $addoptions_value_field4['field4_add_options'];
array_unshift($ex_array,"");
unset($ex_array[0]); 
      	foreach ($ex_array as $key => $value_field4) {

      		echo '<option value='.esc_attr($key).'>'.esc_attr(ucwords($value_field4)).'</option>';

      	}
      ?>
    </select>
<?php	
}
if($tag_select_field4 == 'Textarea'){
?>
   <label for="<?php echo esc_attr(ucwords($inputfield4));?>"><?php echo esc_attr(ucwords($inputfield4));?></label>
    <textarea id="<?php echo esc_attr(ucwords($inputfield4));?>" name="field4" placeholder="<?php echo esc_attr(ucwords($inputfield4));?>" style="height:200px; resize: none;"></textarea>
<?php	
}
?>
    <input type="submit" value="Submit" name="submit" class="submit_customization">

  </form>
</div> 
<?php
	
	if(isset($_POST['submit'])){

	$field1 = esc_attr(ucwords($_POST['field1']));
	$field2 = esc_attr(ucwords($_POST['field2']));
	$field3 = esc_attr(ucwords($_POST['field3']));
	$field4 = esc_attr(ucwords($_POST['field4']));

	if(empty($field1 && $field2 && $field3 && $field4)){
		echo'All Fields Is Required';
	}
	else{

		if($tag_select_field1 == 'Select'){

		$fieldvalueid = $_POST['field1'];
		$field1_email = $addoptions_value_field1['field1_email'];
		array_unshift($field1_email,"");
		unset($field1_email[0]);
		
		$addoptions_value_field1 = $addoptions_value_field1['field1_add_options'];
		array_unshift($addoptions_value_field1,"");
		unset($addoptions_value_field1[0]);
		$addoptionsnew=$addoptions_value_field1[$fieldvalueid];

		$toemail = $field1_email[$fieldvalueid];
		$to = ''.esc_attr(ucwords($toemail)).'';
		$subject = 'Reservation Booking';
		$body = '
		'.esc_attr(ucwords($inputfield1)).' : '.esc_attr(ucwords($addoptionsnew)).'
		<br>
		'.esc_attr(ucwords($inputfield2)).' : '.esc_attr(ucwords($_POST['field2'])).'
		<br>
		'.esc_attr(ucwords($inputfield3)).' : '.esc_attr(ucwords($_POST['field3'])).'
		<br>
		'.esc_attr(ucwords($inputfield4)).' : '.esc_attr(ucwords($_POST['field4'])).'
		<br>
		';

		// echo $body;

		$headers = array('Content-Type: text/html; charset=UTF-8');
		wp_mail( $to, $subject, $body, $headers );


		}
		if($tag_select_field2 == 'Select'){

		$fieldvalueid = $_POST['field2'];
		$field2_email = $addoptions_value_field2['field2_email'];
		array_unshift($field2_email,"");
		unset($field2_email[0]);
		
		$addoptions_value_field2 = $addoptions_value_field2['field2_add_options'];
		array_unshift($addoptions_value_field2,"");
		unset($addoptions_value_field2[0]);
		$addoptionsnew=$addoptions_value_field2[$fieldvalueid];

		$toemail = $field2_email[$fieldvalueid];
		$to = ''.esc_attr(ucwords($toemail)).'';
		$subject = 'Reservation Booking';
		$body = '
		'.esc_attr(ucwords($inputfield1)).' : '.esc_attr(ucwords($_POST['field1'])).'
		<br>
		'.esc_attr(ucwords($inputfield2)).' : '.esc_attr(ucwords($addoptionsnew)).'
		<br>
		'.esc_attr(ucwords($inputfield3)).' : '.esc_attr(ucwords($_POST['field3'])).'
		<br>
		'.esc_attr(ucwords($inputfield4)).' : '.esc_attr(ucwords($_POST['field4'])).'
		<br>
		';
		// echo $body;
		$headers = array('Content-Type: text/html; charset=UTF-8');
		wp_mail( $to, $subject, $body, $headers );
		}

		///*****//

		if($tag_select_field3 == 'Select'){

		$fieldvalueid = $_POST['field3'];
		$field3_email = $addoptions_value_field3['field3_email'];
		array_unshift($field3_email,"");
		unset($field3_email[0]);
		
		$addoptions_value_field3 = $addoptions_value_field3['field3_add_options'];
		array_unshift($addoptions_value_field3,"");
		unset($addoptions_value_field3[0]);
		$addoptionsnew=$addoptions_value_field3[$fieldvalueid];

		$toemail = $field3_email[$fieldvalueid];
		$to = ''.esc_attr(ucwords($toemail)).'';
		$subject = 'Reservation Booking';
		$body = '
		'.esc_attr(ucwords($inputfield1)).' : '.esc_attr(ucwords($_POST['field1'])).'
		<br>
		'.esc_attr(ucwords($inputfield2)).' : '.esc_attr(ucwords($_POST['field2'])).'
		<br>
		'.esc_attr(ucwords($inputfield3)).' : '.esc_attr(ucwords($addoptionsnew)).'
		<br>
		'.esc_attr(ucwords($inputfield4)).' : '.esc_attr(ucwords($_POST['field4'])).'
		<br>
		';
		$headers = array('Content-Type: text/html; charset=UTF-8');
		wp_mail( $to, $subject, $body, $headers );

		// $form_entry = array($inputfield1 => $_POST['field1'],$inputfield2 => $_POST['field2'],$inputfield3 => $addoptionsnew,$inputfield4 => $_POST['field4'] );

		// $option_name = 'form_entry_show';
  //   	add_option( $option_name, $form_entry,true);



		}

		///****////

		if($tag_select_field4 == 'Select'){
			$fieldvalueid = $_POST['field4'];
		$field4_email = $addoptions_value_field4['field4_email'];
		array_unshift($field4_email,"");
		unset($field4_email[0]);
		
		$addoptions_value_field4 = $addoptions_value_field4['field4_add_options'];
		array_unshift($addoptions_value_field4,"");
		unset($addoptions_value_field4[0]);
		$addoptionsnew=$addoptions_value_field4[$fieldvalueid];

		$toemail = $field4_email[$fieldvalueid];
		$to = ''.esc_attr(ucwords($toemail)).'';
		$subject = 'Reservation Booking';
		$body = '
		'.esc_attr(ucwords($inputfield1)).' : '.esc_attr(ucwords($_POST['field1'])).'
		<br>
		'.esc_attr(ucwords($inputfield2)).' : '.esc_attr(ucwords($_POST['field2'])).'
		<br>
		'.esc_attr(ucwords($inputfield3)).' : '.esc_attr(ucwords($_POST['field3'])).'
		<br>
		'.esc_attr(ucwords($inputfield4)).' : '.esc_attr(ucwords($addoptionsnew)).'
		<br>
		';
		
		$headers = array('Content-Type: text/html; charset=UTF-8');
		wp_mail( $to, $subject, $body, $headers );
		}

	}
}


	return ob_get_clean();
}
?>
